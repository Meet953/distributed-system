package question1;

import java.sql.SQLException;
import java.util.*;

import question5.BookDatabase;

public enum BookDao {
	INSTANCE;
	
	private Map<Integer, Book> booksMap = new HashMap<Integer, Book>();
	
	private BookDao() {
		
		Book book1 = new Book();
		book1.setId(1);
		book1.setTitle("RESTful Java with JAX-RS");
		book1.setAuthor("Bill Burke");
		book1.setYear(2009);
		
		booksMap.put(1, book1);
		
		Book book2 = new Book();
		book2.setId(2);
		book2.setTitle("Java message service");
		book2.setAuthor("David A. Chappell, Richard Monson-Haefel");
		book2.setYear(2000);
		
		booksMap.put(2, book2);
	}
	
	public List<Book> getBooks() {
		System.out.println("getall");
		List<Book> books = BookDatabase.selectAllBooks();
	//	books.addAll(booksMap.values());
		return books;
	}
	
	public Book getBook(int id) {
		//return booksMap.get(id);
		System.out.println("get");
		return BookDatabase.selectBook(id);
	}
	
	public void create(Book book) {
		//booksMap.put(book.getId(), book);
		System.out.println("create");
		BookDatabase.insertBook(book);
	}
	
	public void delete(int id) {

		System.out.println("delete");
		BookDatabase.deleteBook(id);
		
	}

	public void update(Book book) {
		System.out.println("update");
		BookDatabase.updateBook(book);
		
	}
}
