package databaseSetup;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateTableExample {

	public static void main(String[] args) throws Exception {
		Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/oneDB", "SA", "Passw0rd");
		Statement stmt = conn.createStatement();
		
		stmt.executeUpdate("CREATE TABLE IF NOT EXISTS BOOK(id INTEGER IDENTITY, author VARCHAR(32) NOT NULL, title VARCHAR(32) NOT NULL, year INTEGER NOT NULL)");

	}

}
