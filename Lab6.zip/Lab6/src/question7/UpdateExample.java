package question7;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UpdateExample {

	public static void main(String[] args) throws Exception {
		Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/oneDB", "SA", "Passw0rd");
		Statement stmt = conn.createStatement();
		
		stmt.executeUpdate("UPDATE user SET name='Frank' where id='0'");
	}
}
