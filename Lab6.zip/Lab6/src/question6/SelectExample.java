package question6;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SelectExample {

	public static void main(String[] args) throws Exception {
		Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/oneDB", "SA", "Passw0rd");
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT id, name, address FROM USER");
		
		while (rs.next()) {
			String id = rs.getString("id");
			String name = rs.getString("name");
			String address = rs.getString("address");
			System.out.println("ID: " + id + ", Name: " + name + ", Address: " + address);
		}
	}
}
