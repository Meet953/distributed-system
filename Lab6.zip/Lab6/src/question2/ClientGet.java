package question2;

import java.net.URI;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse; 
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import question1.Book;

 
 
public class ClientGet {
	
	public static void main (String[] args) throws Exception {
		URI uri = new URIBuilder()
				.setScheme("http")
				.setHost("localhost")
				.setPort(8080)
				.setPath("/Lab6/rest/books/16").build();
		
		System.out.println(uri.toString());
		
		HttpGet httpGet = new HttpGet(uri);
		httpGet.setHeader("Accept", "application/xml");
		
		CloseableHttpClient httpClient = HttpClients.createDefault();
		CloseableHttpResponse response = httpClient.execute(httpGet);
		
		HttpEntity entity = response.getEntity();
		String text = EntityUtils.toString(entity);
		System.out.println(text);
		
		Book book = new ParseBook().doParseBook(text);
		System.out.println("-------------------------");
		System.out.println("ID: " + book.getId());
		System.out.println("Title: " + book.getTitle());
		System.out.println("Author: " + book.getAuthor());
		System.out.println("Year: " + book.getYear());
		
	}
}
